# Copyright Alper KUM 2023, BSD 3-Clause license
"""
Colorama_EX Init Module
"""

__version__ = '0.4.6_ex'